export let selectOptions = [
    {
        label: 'Spain',
        code:  'ES'
    },
    {
        label: 'United Kingdom',
        code: 'GB'
    },
    {
        label: 'France',
        code: 'FR',
    },
    {
        label: 'Portugal',
        code: 'PT'
    }
]