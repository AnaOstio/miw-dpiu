import {Layout} from 'antd';

let FooterApp = () => {
    return (
        <Layout.Footer style={{ textAlign: "center" }}>Wallapep</Layout.Footer>
    )
}

export default FooterApp;