import { Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { Layout, notification } from 'antd';
import { useState, useEffect } from "react";
import LoginFormComponent from "./components/user/LoginFormComponent";
import CreateUserComponent from "./components/user/CreateUserComponent";
import ListProductsComponent from "./components/products/ListProductsComponent";
import DetailsProductComponent from "./components/products/DetailsProductComponent";
import CreateProductComponent from "./components/products/CreateProductComponent";
import ListMyProductsComponent from "./components/products/ListMyProductsComponent";
import MenuApp from "./components/common/MenuApp";
import EditProductComponent from "./components/products/EditProductComponent";
import FooterApp from "./components/common/FooterApp";
import MyTransactionsComponent from "./components/transactions/MyTransactionsComponent";
import ProfileUser from "./components/user/ProfileUser";
import LandingComponent from "./components/landing/LandingComponent";

let App = () => {
    const [api, contextHolder] = notification.useNotification();
    let { Header, Content } = Layout;
    let [login, setLogin] = useState(false);
    let navigate = useNavigate();
    let location = useLocation();

    // Comprueba si la sesión está activa al cargar
    useEffect(() => {
        checkAll()
    }, []);

    let checkAll = async () => {
        let isActive = await checkLoginIsActive()
        checkUserAccess(isActive)
    }

    let checkUserAccess = async (isActive) => {
        let href = location.pathname
        if (!isActive && !["/", "/login", "/register"].includes(href)) {
            navigate("/login")
        }
    }

    let checkLoginIsActive = async () => {
        if (localStorage.getItem("apiKey") == null) {
            setLogin(false);
            return;
        }

        let response = await fetch(
            process.env.REACT_APP_BACKEND_BASE_URL + "/users/isActiveApiKey",
            {
                method: "GET",
                headers: {
                    "apikey": localStorage.getItem("apiKey")
                }
            }
        );

        if (response.ok) {
            let jsonData = await response.json();
            setLogin(jsonData.activeApiKey);

            if (!jsonData.activeApiKey) {
                navigate("/login");
            }
            return (jsonData.activeApiKey)
        } else {
            setLogin(false);
            navigate("/login");
            return (false)
        }
    }

    // Funcion para crear notifiaciones
    const openNotification = (placement, text, type) => {
        api[type]({
            message: 'Notification',
            description: text,
            placement,
        });
    };


    return (
        <Layout className="layout" style={{ minHeight: "100vh" }}>
            {contextHolder}
            <Header style={{height:'100%'}}>
                <MenuApp login={login} setLogin={setLogin} />
            </Header>
            <Content style={{ padding: "20px 50px" }}>
                <div className="site-layout-content">
                    <Routes>
                        <Route path="/" element={<LandingComponent />} />
                        <Route path="/register" element={<CreateUserComponent setLogin={setLogin} openNotification={openNotification} />} />
                        <Route path="/login" element={<LoginFormComponent setLogin={setLogin} openNotification={openNotification} />} />
                        <Route path="/all-products/:category" element={<ListProductsComponent openNotification={openNotification} />} />
                        <Route path="/products/edit/:id" element={<EditProductComponent openNotification={openNotification} />} />
                        <Route path="/products/:id" element={<DetailsProductComponent openNotification={openNotification} />} />
                        <Route path="/products/create" element={<CreateProductComponent openNotification={openNotification} />} />
                        <Route path="/products/own" element={<ListMyProductsComponent openNotification={openNotification} />} />
                        <Route path="/myTransactions" element={<MyTransactionsComponent openNotification={openNotification} />} />
                        <Route path="/profile/:userId" element={<ProfileUser openNotification={openNotification} />} />
                    </Routes>
                </div>
            </Content>
            <FooterApp />
        </Layout>
    );
}

export default App;
